create table stores(
invoice_and_item_number varchar primary key,
date date,
store_number int,
store_name varchar,
address varchar,
city varchar,
zip_code int,
country_number int,
country varchar,
category_id int,
category_name varchar	
);

select * from  stores
------------------------------------

create table sales (
vendor_number int,
vendor_name varchar,
item_number int,
item_description varchar,
store_number int,
pack int,
bottle_volume_ml int,
state_bottle_cost double precision,
state_bottle_retail  double precision,
bottles_sold int,
sale_dollars  double precision,
volume_sold_liters  double precision,
valume_sold_gallons  double precision
);

select * from sales

