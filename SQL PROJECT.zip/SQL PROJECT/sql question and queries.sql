--que_1--write a sql query to get the store name and sum of total sale,where sale_dollers greater than $1000.

select store_name,sum(sale_dollars) as total_sale from sales as s
inner join stores as st
on s.store_number = st.store_number
where sale_dollars > '1000'
group by store_name

-----------------------------------------------------------------
--que_2--write a sql query to return state_bottle_cost is greater than the average of state_bottl_cost.

select avg(state_bottle_cost) from sales 

select * from sales where state_bottle_cost > (select avg(state_bottle_cost) from sales);

-----------------------------------------------------------------
--que_3--write a sql query to get the store number and store name of all category name 
--that have sold liquor more than 50 liter

select st.store_number,st.store_name,st.category_name,s.volume_sold_liters from stores as st
inner join sales as s 
on s.store_number = st.store_number
group by st.store_number,st.store_name,st.category_name,s.volume_sold_liters
having volume_sold_liters >= 50

-----------------------------------------------------------------
--que_4--write a sql query for count the number of distinct categories that sold 
--more than 100 bottles between 2021-01-01 and 2021-12-31.

select count(distinct category_name) as total_category from stores as st
inner join sales as s
on st.store_number = s.store_number
where date between '2021-01-01' and' 2021-12-31'
and bottles_sold > '100';

---------------------------------------------end----------------------------------------

